#define pthread_create hw5_pthread_create
#define accept hw5_accept
